package com.knapp.codingcontest.kcc2021.solution;

public class CordSaver {
    int x;
    int y;

    public CordSaver(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }
}
